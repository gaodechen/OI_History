#include	<cstdio>
#include	<cstring>
#include	<iostream>
#include	<algorithm>

using	namespace	std;

int main()
{
	freopen( "a.in", "r", stdin );
	return 0;
}
