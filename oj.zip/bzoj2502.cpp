#include    <cstdio>
#include    <cstring>
#include    <iostream>

using   namespace   std;
const   int N = 1e2 + 5;

int main()
{
    return 0;
}
